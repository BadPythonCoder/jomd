# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['jomd']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'jomd',
    'version': '0.1.0',
    'description': 'A python packages for creating and seeing higher or lower dimensional shapes and objects.',
    'long_description': None,
    'author': 'BadPythonCoder',
    'author_email': 'haha@no.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
