__version__ = '0.1.0'

import Test

class Test:
  def __init__(self, udck):
    self.duck = udck
  def suss(self):
    return self.duck