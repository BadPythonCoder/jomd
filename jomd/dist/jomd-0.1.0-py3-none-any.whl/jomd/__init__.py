'''
Just One More Dimension

THIS IS THE ORIGINAL, to all of the stealers. For real tho, idk why you would want to fork it other then improve my bad code.

Yeah i am not that proffesional, i just kinda do my own thing. I do this in my free time, so don't expect me to be proffesional xd.

Also i am gonna attempt to improve my ways from the last time that i made hyperdimensional objects, cuz then i couldn't like rotate it in the cool dimensions and i assume that is because of the projection matrix i used and that may or may not be cuz of numpy. BUT this time i am not gonna use that and gonna do it myself.

BTW do not complain, i said that this was a bad library.... Actually do whatever you want, just don't hate me because it doesn't work. But pls still post issues cuz it will help me a l o t.

The packages that will be used are: pygame, threading
'''
from .screen import *
__version__ = '0.1.0'
