def point(window, x, y):
  window.drawings.append((window.dot, (x, y)))