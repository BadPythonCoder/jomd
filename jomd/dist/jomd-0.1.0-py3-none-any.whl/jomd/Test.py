def testduc():
  print('yeahh')